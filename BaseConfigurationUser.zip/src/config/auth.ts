export default {
  jwt: {
    secret: 'deea15e55fc9626531346673cd8a1d14',
    expireIn: '1d',
  },
};
